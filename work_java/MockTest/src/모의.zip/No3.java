// 문제 잘 읽고...가지 치기...끊어주기 잘 하기...
import java.io.*;
import java.util.*;

public class No3 {

	static int result;
	static int[] card;

	static Queue<Card> q = new ArrayDeque<>();

	// 카드.. 왼쪽, 오른쪽 나눈 정보 다 있슴.. depth: 셔플 횟수 
	private static class Card {
		int[] cards = new int[card.length];
		int[] cards1 = new int[card.length / 2];
		int[] cards2 = new int[card.length / 2];
		int depth;

		public Card(int[] cards, int depth, int[] cards1, int[] cards2) {
			this.cards = cards.clone();
			this.depth = depth;
			this.cards1 = cards1.clone();
			this.cards2 = cards2.clone();
		}
	}

	public static void main(String[] args) throws Exception {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(in.readLine());

		for (int test_case = 1; test_case <= T; test_case++) {
			sb.append("#" + test_case + " ");
			
			q.clear();

			int N = Integer.parseInt(in.readLine()); // 카드 개수

			String[] split = in.readLine().split(" ");

			card = new int[N];
			for (int i = 0; i < N; i++) {
				card[i] = Integer.parseInt(split[i]);
			}
			
			// 카드 나누기
			int[] card1 = new int[N / 2];
			int[] card2 = new int[N / 2];
			divide(card1, card2, card);

			// 첫번 째 확인 -> x = 0 
			q.offer(new Card(card, 0, card1, card2));
			int result = 0;
			if (Up(card)) {
				result = 0;
			}
			else if (Down(card)) {
				result = 0;
			}
			else {
				q.offer(new Card(card, 0, card1, card2));
				result = bfs();
			}
			sb.append(result).append("\n");

		}
		System.out.println(sb);
	}

	// 카드 반 나눈기
	private static void divide(int[] card1, int[] card2, int[] card) {
		int N = card.length;
		for (int i = 0; i < N / 2; i++) {
			card1[i] = card[i];
		}
		for (int i = N / 2; i < N; i++) {
			card2[i - N / 2] = card[i];
		}
	}

	private static int bfs() {

		int depth = 0;
		
		while (!q.isEmpty()) {
			int size = q.size();
			
			if(depth > 4) // 5번 이상 넘어가면 return (depth 0부터 시작해서 4 넘어갈 때)  
				return -1;
			
			for (int s = 0; s < size; s++) {
				Card c = q.poll();
				
				int N = c.cards.length;

				
				// 셔플 -> x에 따라 
				for (int x = 0; x < card.length; x++) {
					
					for (int i = 0; i < N; i++) {
						if (i + 1 < N && search(c.cards1, c.cards[i]) && search(c.cards2, c.cards[i + 1])) {
							swap(c.cards, i, i + 1);
							i = i + 1;
						}
					}
					if (Up(c.cards)) {
						return c.depth + 1;
					}
					if (Down(c.cards)) {
						return c.depth + 1;
					}
					int[] card1 = new int[card.length / 2];
					int[] card2 = new int[card.length / 2];
					divide(card1, card2, c.cards);
					q.offer(new Card(c.cards, depth + 1, card1, card2));

				}
			}
			depth++;
		}
		return -1;

	}

	// 내림차순 확인
	private static boolean Down(int[] card) {
		for (int i = 0; i < card.length - 1; i++) {
			if (card[i] < card[i + 1])
				return false;
		}
		return true;
	}

	// 오름차순 확인
	private static boolean Up(int[] card) {
		for (int i = 0; i < card.length - 1; i++) {
			if (card[i] > card[i + 1])
				return false;
		}
		return true;
	}

	// 셔플에 필요한 swap
	private static void swap(int[] card, int i, int j) {
		int tmp = card[i];
		card[i] = card[j];
		card[j] = tmp;
	}

	// 카드가 어느 쪽에 속하는지 -> 왼쪽? 오른쪽?
	private static boolean search(int[] card, int target) {
		for (int i = 0; i < card.length; i++) {
			if (card[i] == target)
				return true;
		}
		return false;
	}
}

