
import java.io.*;
import java.util.*;

public class No1 {

	// 1. 출입구 선택 - 순열
	// 2. 낚시꾼 배치 -> 홀수인 경우 배치 신경써야 함
	// 3. 거리 계산???

	private static class Gate {

		int num;
		int Fisher;

		public Gate(int num, int Fisher) {
			this.num = num;
			this.Fisher = Fisher;
		}

	}

	private static boolean[] visited;
	private static Gate[] gates;
	private static int[] map;
	private static int min;
	private static int N;

	private static int fisherCnt;

	public static void main(String[] args) throws Exception {

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(in.readLine());

		for (int tc = 1; tc <= T; tc++) {
			sb.append("#" + tc + " ");

			min = Integer.MAX_VALUE;

			N = Integer.parseInt(in.readLine());

			gates = new Gate[4];
			map = new int[N + 1];

			for (int i = 1; i <= 3; i++) {
				String[] split = in.readLine().split(" ");
				int num = Integer.parseInt(split[0]);
				int fisher = Integer.parseInt(split[1]);

				gates[i] = new Gate(num, fisher);
			}
			
			visited = new boolean[4];

			perm(0, 0);
			
			sb.append(min).append("\n");

		}

		System.out.println(sb);
	}

	private static int Right(int distance, int i) {

		int idx = gates[i].num + distance;
		
		if (idx <= N && map[idx] == 0) {
			map[idx] = gates[i].num;
			fisherCnt++;
			return distance + 1;
		}

		return 0;

	}

	private static int Left(int distance, int i) {

		int idx = gates[i].num - distance;

		if (idx >= 1 && map[idx] == 0) {
			map[idx] = gates[i].num;
			fisherCnt++;
			return distance + 1;
		}

		return 0;

	}

	private static int inFisher(int i, Gate gate, boolean flag) {

		int distance = 0;
		fisherCnt = 0;
		int sum = 0;

		while (fisherCnt < gate.Fisher) {

			if (flag) {
				sum += Left(distance, i);
			} else {
				sum += Right(distance, i);
			}

			if (gate.Fisher == fisherCnt)
				break;

			if (flag) {
				sum += Right(distance, i);
			} else {
				sum += Left(distance, i);
			}

			distance++;
		}

		return sum;
	}

	private static void outFisher(int i) {


		for (int idx = 1; idx <= N; idx++) {
			if (map[idx] == gates[i].num) 
				map[idx] = 0;

		}

	}

	private static void perm(int cnt, int sum) {

		if (sum > min) {
			return;
		}

		if (cnt == 3) {
			min = Math.min(min, sum);
			return;
		}

		for (int i = 1; i <= 3; i++) {

			if (visited[i])
				continue;

			visited[i] = true;

			// 짝수일 때 -> 양쪽만 하면 됨 -> 왼족 -> 오른쪽
			perm(cnt + 1, sum + inFisher(i, gates[i], true));
			outFisher(i);

			// 홀수일 때 -> 한 쪽 더 비교 -> 오른쪽 -> 왼쪽
			if (gates[i].Fisher % 2 == 0) {
				perm(cnt + 1, sum + inFisher(i, gates[i], false));
				outFisher(i);
			}

			visited[i] = false;

		}

	}

}
