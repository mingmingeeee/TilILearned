package com.ssafy.home.dao;

public class HomeDao {

}
